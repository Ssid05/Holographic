import SwiftUI

struct MainInterfaceView: View {
    @EnvironmentObject private var model: AppViewModel
    @StateObject private var motion = MotionParallaxManager()
    @State private var locationLabel: String = "Moradabad"

    var body: some View {
        ZStack {
            GradientBackground().ignoresSafeArea()
            ParticleBackground(animate: model.boostEffects)

            VStack(spacing: 0) {
                StatusBarView(onEnd: model.endDemo, onToggleDemo: model.toggleDemoMode, strongEffects: model.boostEffects, location: locationLabel)
                    .padding(.top, 8)

                GeometryReader { geo in
                    ZStack {
                        ForEach(model.activeWindowsSorted()) { window in
                            FloatingWindow(window: window,
                                           boost: model.boostEffects,
                                           parallax: motion,
                                           onClose: { model.closeWindow(id: window.id) },
                                           onFocus: { model.focusWindow(id: window.id) },
                                           onMinimize: { model.minimizeWindow(id: window.id) },
                                           onDrag: { translation in model.moveWindow(id: window.id, by: translation) })
                            .frame(width: window.size.width, height: window.size.height)
                            .position(x: window.position.x, y: window.position.y)
                            .zIndex(Double(window.zIndex))
                        }
                    }
                    .onAppear {
                        model.updateCanvasSize(geo.size)
                        motion.start(intensity: model.boostEffects ? 18 : 8)
                    }
                    .onChange(of: geo.size) { model.updateCanvasSize($0) }
                }

                DockView(parallax: motion)
                    .padding(.bottom, 8)
            }
            .padding(.horizontal, 12)
        }
        .task { await preloadLocationLabel() }
    }

    private func preloadLocationLabel() async {
        let service = WeatherService()
        if let city = try? await service.reverseGeocode(lat: 28.8389, lon: 78.7768) {
            locationLabel = city
        }
    }
}

private struct FloatingWindow: View {
    let window: WindowInstance
    let boost: Bool
    @ObservedObject var parallax: MotionParallaxManager
    let onClose: () -> Void
    let onFocus: () -> Void
    let onMinimize: () -> Void
    let onDrag: (CGSize) -> Void

    @State private var dragOffset: CGSize = .zero
    @State private var hover = false

    var body: some View {
        VStack(spacing: 12) {
            WindowChrome(title: window.app.title, app: window.app, onClose: onClose, onMinimize: onMinimize, onFocus: onFocus)
                .padding(.horizontal, 2)

            Group {
                switch window.app {
                case .dashboard: DashboardAppView()
                case .weather: WeatherAppView()
                case .notes: NotesAppView()
                case .music: MusicAppView()
                case .calculator: CalculatorAppView()
                case .assistant: AssistantAppView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .padding(12)
        .glassCard(cornerRadius: 24, glow: boost)
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(LinearGradient(colors: [Color.white.opacity(0.25), Color.blue.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: boost ? 1.2 : 0.6)
        )
        .scaleEffect(window.isMinimized ? 0.85 : 1, anchor: .topTrailing)
        .opacity(window.isMinimized ? 0.7 : 1)
        .offset(dragOffset)
        .offset(y: hover ? -6 : 6)
        .parallax(parallax, depth: boost ? 0.12 : 0.06)
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    dragOffset = value.translation
                    onFocus()
                }
                .onEnded { value in
                    onDrag(value.translation)
                    dragOffset = .zero
                }
        )
        .onTapGesture { onFocus() }
        .onAppear {
            withAnimation(.easeInOut(duration: 6).repeatForever(autoreverses: true)) { hover.toggle() }
        }
        .animation(.spring(response: 0.48, dampingFraction: 0.82), value: window.isMinimized)
    }
}
