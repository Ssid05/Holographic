import SwiftUI

struct DockView: View {
    @EnvironmentObject private var model: AppViewModel
    var parallax: MotionParallaxManager?

    var body: some View {
        HStack(spacing: 16) {
            ForEach(model.dockApps) { app in
                Button { model.open(app: app) } label: {
                    VStack(spacing: 6) {
                        Image(systemName: app.symbol)
                            .font(.system(size: 22, weight: .semibold))
                        Text(app.title)
                            .font(.caption)
                            .foregroundStyle(.primary.opacity(0.8))
                    }
                    .padding(12)
                    .frame(width: 88, height: 88)
                    .glassCard(cornerRadius: 22, glow: model.boostEffects)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 18)
        .background(
            Capsule(style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(Capsule(style: .continuous).stroke(Color.white.opacity(0.15), lineWidth: 1))
                .shadow(color: Color.black.opacity(0.22), radius: 20, x: 0, y: 12)
        )
        .padding(.bottom, 24)
        .padding(.top, 8)
        .parallax(parallax ?? MotionParallaxManager(), depth: 0.08)
    }
}
