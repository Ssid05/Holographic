import SwiftUI

struct StatusBarView: View {
    var onEnd: () -> Void
    var onToggleDemo: () -> Void
    var strongEffects: Bool
    var location: String

    var body: some View {
        HStack(spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: "sparkles")
                Text("Vision Canvas")
            }
            .font(.system(.subheadline, design: .rounded).weight(.semibold))
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .glassCard(cornerRadius: 16, glow: strongEffects, shadowOpacity: 0.18)

            Spacer()

            HStack(spacing: 16) {
                Label("\(Date(), formatter: Self.timeFormatter)", systemImage: "clock")
                Label(location, systemImage: "location.fill")
                Button(action: onToggleDemo) {
                    Label(strongEffects ? "Demo Mode" : "Calm Mode", systemImage: strongEffects ? "aqi.medium" : "circle.grid.cross")
                }
                .buttonStyle(.borderedProminent)
                .tint(strongEffects ? .blue : .gray)
                Button(action: onEnd) {
                    Label("End", systemImage: "xmark.circle.fill")
                }
                .buttonStyle(.bordered)
            }
            .labelStyle(.titleAndIcon)
            .font(.system(.subheadline, design: .rounded).weight(.semibold))
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .glassCard(cornerRadius: 16, glow: strongEffects, shadowOpacity: 0.14)
        }
        .foregroundStyle(.primary)
        .padding(.horizontal, 24)
        .padding(.top, 10)
    }

    private static let timeFormatter: DateFormatter = {
        let df = DateFormatter()
        df.dateFormat = "HH:mm"
        return df
    }()
}
